import React from 'react';

export default function App() {
  return (
    <div className="container">
      <h1>Khushboo, you are the most beautiful part of my world.</h1>
      <p>I love you forever ❤️</p>
      <footer>— Chandu Yadav</footer>
    </div>
  );
}
